import time
import requests
import random
from telebot import types
import telebot

bot = telebot.TeleBot('7317834600:AAGwJKiE9m92fqs_1lL4YQyvxcW9eJLSu8c')
name=''
surname=''
age=0
a = 0
coin = 0
funny_users_name = ['Умняшка','Чебупель','Сникерс',
                    'Пипин Короткий','Черешня',
                    'Хрюшка','Ложка','Арматура']

help_bot = " 1. /hello - Поздороваться\n" \
           "2. /reg - Регистрация \n" \
          "3. /game - Игра больше|меньше \n" \
           "4. /flipCoin - Бросок монетки \n" \
          "5. /rollTheDice - Бросок кубика\n" \
           "6. /nameTd - Выберите себе имя на сегодня \n" \
           "7. /randomDogs - Фото случайной собаки \n" \
           "8. /randomFoxes - Фото случайной лисы \n" \
           "9. /randomCats - Фото случайного кота"


@bot.message_handler(content_types=['text','document','audio'])
def get_text_messages(message):
    global a
    global coin
    if message.text == "/hello":
        bot.send_message(message.from_user.id, "Привет " + message.from_user.first_name+' '+ message.from_user.last_name)
    elif message.text=="/help":
        bot.send_message(message.from_user.id,help_bot)
    elif message.text=="/reg":
        bot.send_message(message.from_user.id, "Напишите свое имя")
        bot.register_next_step_handler(message,get_name)
    elif message.text=="/game":
        a=random.randint(1,100)
        bot.send_message(message.from_user.id,"Я загадал число 1 одного до 100, попробуй угадать")
        bot.register_next_step_handler(message,game)
    elif message.text=="/flipCoin":
        flipCoin(message)
    elif message.text=="/rollTheDice":
        bot.send_message(message.from_user.id, random.randint(1,6))
    elif message.text=="/randomDogs":
        getDogs(message)
    elif  message.text=="/randomFoxes":
        getFox(message)
    elif  message.text=="/randomCats":
        getCat(message)
    elif message.text=='/nameTd':
        randomusername = random.choice(funny_users_name)
        bot.send_message(message.from_user.id,'сегодня вы: '+randomusername)
    else:
        bot.send_message(message.from_user.id, "Я тебя не понимаю. напишите /help")


def getDogs(message):
    result = requests.get("https://random.dog/woof.json/").json()
    send_mess = f"<b>{message.from_user.first_name} {message.from_user.last_name}</b>, вот ваша картинка:"
    bot.send_message(message.from_user.id, send_mess, parse_mode='html')
    bot.send_photo(message.from_user.id, result["url"])


def getFox(message):
    rand_fox_id = random.randint(1,121)
    result = f"https://randomfox.ca/images/{rand_fox_id}.jpg"
    bot.send_message(message.from_user.id, 'Вот картинка лисички')
    bot.send_photo(message.from_user.id, result)

def getCat(message):
    result = f"https://cataas.com/cat"
    bot.send_message(message.from_user.id, 'Вот картинка котика')
    bot.send_photo(message.from_user.id, result)


def flipCoin(message):
    coin = random.randint(1, 2)
    if coin == 1:
        bot.send_message(message.from_user.id, "Орел")
    else:
        bot.send_message(message.from_user.id, "Решка")
def game(message):
    if str(a)<message.text:
        bot.send_message(message.from_user.id,"Загаданное число меньше")
        bot.register_next_step_handler(message,game)
    elif str(a)>message.text:
        bot.send_message(message.from_user.id,"Загаданное число больше")
        bot.register_next_step_handler(message, game)
    elif str(a)==message.text:
        bot.send_message(message.from_user.id,"Угадали")


def get_name(message):
    global name
    name = message.text
    bot.send_message(message.from_user.id,"Напишите свою фамилию")
    bot.register_next_step_handler(message,get_surname)

def get_surname(message):
    global surname
    surname = message.text
    bot.send_message(message.from_user.id,"Напишите свой возраст")
    bot.register_next_step_handler(message,get_age)

def get_age(message):
    global age
    while age==0:
        try:
            age = int(message.text)
        except Exception:
            bot.send_message(message.from_user.id,'Введите возраст только цифрами')
    #bot.send_message(message.from_user.id,'Тебе - '+str(age)+'\n'+'Тебя зовут - '+ name + '\n'+ 'Твоя фамилия - ' + surname)
    keyboard = types.InlineKeyboardMarkup()
    key_yes = types.InlineKeyboardButton(text = 'Да', callback_data='yes')
    keyboard.add(key_yes)
    key_no = types.InlineKeyboardButton(text='Нет', callback_data='no')
    keyboard.add(key_no)
    question = 'Тебе - '+str(age)+'\n'+'Тебя зовут - '+ name + '\n'+ 'Твоя фамилия - ' + surname + '\n' + 'Все введено верно?'
    bot.send_message(message.from_user.id,text=question,reply_markup=keyboard)

@bot.callback_query_handler(func=lambda call: True)
def callback_worker(call):
    if call.data == 'yes':
        bot.send_message(call.from_user.id,'Спасибо, сохранили ваши данные')
    elif call.data=='no':
        bot.send_message(call.from_user.id, 'Попробуйте зарегистрироваться еще раз')


bot.polling(none_stop=True,interval=0)